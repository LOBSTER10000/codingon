const { User } = require('../models');
const bcrypt = require('bcrypt');
const output = {
  index: (req, res) => {
    const userid = req.session.userid;
    const name = req.session.name;

    res.render('index', {
      userid: userid,
      name: name,
    });
  },

  login: (req, res) => {
    res.render('login');
  },

  post: (req, res) => {
    res.render('post');
  },

  profile: async (req, res) => {
    const id = req.session.user.id;
    const result1 = await User.findOne({
      where: {
        id: id,
      },
    });
    console.log(result1);
    if (result1) {
      res.render('profile', {
        data: result1,
      });
    } else {
      res.redirect('/login');
    }
  },

  user: async (req, res) => {
    const data = await User.findAll();
    console.log(data);
    return res.render('users', {
      data: data,
    });
  },
};

const input = {
  post: async (req, res) => {
    function hashPassword(password) {
      return bcrypt.hashSync(password, 10);
    }

    const pw1 = hashPassword(req.body.pw);

    const result = await User.create({
      userid: req.body.userid,
      pw: pw1,
      name: req.body.name,
    });
    console.log(result);
    res.send(result);
  },

  login: async (req, res) => {
    function comparePassword(password, hashedPassword) {
      return bcrypt.compareSync(password, hashedPassword);
    }

    function hashPassword(password) {
      return bcrypt.hashSync(password, 10);
    }

    const pw1 = hashPassword(req.body.pw);

    const pw2 = comparePassword(req.body.pw, pw1);
    if (pw2 === true) {
      const result2 = await User.findOne({
        where: {
          userid: req.body.userid,
        },
      });

      if (result2) {
        console.log(result2);
        req.session.user = result2;
        req.session.userid = result2.userid;
        req.session.name = result2.name;
        console.log('req.session' + req.session.name);
        req.session.id = result2.id;
        console.log('req.session' + req.session.id);
        res.send({
          data: result2,
        });
      } else {
        res.send('실패했습니다');
      }
    }
  },

  profile: async (req, res) => {
    const result2 = await User.update(
      {
        name: req.body.name,
      },
      {
        where: {
          id: req.session.id,
        },
      }
    );
    return res.send({
      data: result2,
    });
  },
  logout: async (req, res) => {
    req.session.destroy((error) => {
      if (error) {
        res.send('로그아웃 실패');
      } else {
        res.redirect('/');
      }
    });
  },
};
module.exports = { output, input };
